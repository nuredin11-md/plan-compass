
-- 1. Fix: profiles missing INSERT policy (breaks user registration via trigger)
CREATE POLICY "Users can insert own profile"
ON public.profiles
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- 2. Fix: data_uploads SELECT policy - remove uploaded_by bypass
DROP POLICY IF EXISTS "Can view uploads for accessible departments" ON public.data_uploads;
CREATE POLICY "Can view uploads for accessible departments"
ON public.data_uploads
FOR SELECT
USING (can_access_department(auth.uid(), department_id));

-- 3. Fix: can_access_department - restrict data_officer to own department only
CREATE OR REPLACE FUNCTION public.can_access_department(_user_id UUID, _dept_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 
    public.has_role(_user_id, 'admin') OR
    (public.get_user_department(_user_id) = _dept_id)
$$;

-- 4. Fix: Storage policies - restrict by role and department
DROP POLICY IF EXISTS "Users can view uploaded files" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can upload files" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can upload reports" ON storage.objects;

CREATE POLICY "Users can view own department files"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id IN ('uploads', 'reports') AND (
    public.has_role(auth.uid(), 'admin') OR
    (storage.foldername(name))[1]::uuid IN (
      SELECT department_id FROM public.profiles
      WHERE user_id = auth.uid() AND department_id IS NOT NULL
    )
  )
);

CREATE POLICY "Officers can upload department files"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'uploads' AND
  (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'data_officer'))
);

CREATE POLICY "Officers can upload reports"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'reports' AND
  (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'data_officer'))
);

CREATE POLICY "Admin can delete files"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id IN ('uploads', 'reports') AND
  public.has_role(auth.uid(), 'admin')
);
