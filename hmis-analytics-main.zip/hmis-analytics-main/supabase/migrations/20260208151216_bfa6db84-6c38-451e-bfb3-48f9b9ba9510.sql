
-- =============================================
-- HMIS & M&E Analytics Platform - Full Schema
-- =============================================

-- 1. Role enum
CREATE TYPE public.app_role AS ENUM ('admin', 'data_officer', 'department_head', 'viewer');

-- 2. Departments table
CREATE TABLE public.departments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;

-- 3. Profiles table
CREATE TABLE public.profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  department_id UUID REFERENCES public.departments(id),
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- 4. User roles table (separate from profiles!)
CREATE TABLE public.user_roles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- 5. Health indicators
CREATE TABLE public.health_indicators (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  category TEXT,
  unit TEXT DEFAULT 'count',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.health_indicators ENABLE ROW LEVEL SECURITY;

-- 6. Hospital plans/targets
CREATE TABLE public.hospital_plans (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  department_id UUID NOT NULL REFERENCES public.departments(id),
  indicator_id UUID NOT NULL REFERENCES public.health_indicators(id),
  year INT NOT NULL,
  month INT,
  target_value NUMERIC NOT NULL,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.hospital_plans ENABLE ROW LEVEL SECURITY;

-- 7. Data uploads
CREATE TABLE public.data_uploads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_type TEXT NOT NULL,
  file_size BIGINT,
  department_id UUID REFERENCES public.departments(id),
  year INT,
  month INT,
  status TEXT NOT NULL DEFAULT 'pending',
  uploaded_by UUID NOT NULL REFERENCES auth.users(id),
  parsed_data JSONB,
  validation_errors JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.data_uploads ENABLE ROW LEVEL SECURITY;

-- 8. Data quality analysis
CREATE TABLE public.data_quality_analyses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  upload_id UUID NOT NULL REFERENCES public.data_uploads(id) ON DELETE CASCADE,
  department_id UUID REFERENCES public.departments(id),
  completeness_score NUMERIC,
  consistency_score NUMERIC,
  accuracy_score NUMERIC,
  timeliness_score NUMERIC,
  overall_score NUMERIC,
  findings JSONB,
  recommendations JSONB,
  analyzed_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.data_quality_analyses ENABLE ROW LEVEL SECURITY;

-- 9. Performance gap analysis
CREATE TABLE public.performance_gap_analyses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  upload_id UUID REFERENCES public.data_uploads(id),
  department_id UUID REFERENCES public.departments(id),
  period_year INT NOT NULL,
  period_month INT,
  gaps JSONB,
  insights JSONB,
  analyzed_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.performance_gap_analyses ENABLE ROW LEVEL SECURITY;

-- 10. Reports
CREATE TABLE public.reports (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  report_type TEXT NOT NULL DEFAULT 'monthly',
  department_id UUID REFERENCES public.departments(id),
  period_year INT NOT NULL,
  period_month INT,
  content JSONB,
  narrative TEXT,
  file_path TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  generated_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;

-- =============================================
-- Helper functions (SECURITY DEFINER to avoid RLS recursion)
-- =============================================

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE OR REPLACE FUNCTION public.get_user_department(_user_id UUID)
RETURNS UUID
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT department_id FROM public.profiles
  WHERE user_id = _user_id
  LIMIT 1
$$;

CREATE OR REPLACE FUNCTION public.can_access_department(_user_id UUID, _dept_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 
    public.has_role(_user_id, 'admin') OR
    public.has_role(_user_id, 'data_officer') OR
    (public.get_user_department(_user_id) = _dept_id)
$$;

-- Updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, email, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email)
  );
  -- Assign default 'viewer' role
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'viewer');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Updated_at triggers
CREATE TRIGGER update_departments_updated_at BEFORE UPDATE ON public.departments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_hospital_plans_updated_at BEFORE UPDATE ON public.hospital_plans FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_data_uploads_updated_at BEFORE UPDATE ON public.data_uploads FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_reports_updated_at BEFORE UPDATE ON public.reports FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =============================================
-- RLS Policies
-- =============================================

-- Profiles
CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Admin can view all profiles" ON public.profiles FOR SELECT USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Admin can update all profiles" ON public.profiles FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admin can delete profiles" ON public.profiles FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- User roles
CREATE POLICY "Users can view own roles" ON public.user_roles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Admin can view all roles" ON public.user_roles FOR SELECT USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admin can manage roles" ON public.user_roles FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admin can update roles" ON public.user_roles FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admin can delete roles" ON public.user_roles FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- Departments
CREATE POLICY "Authenticated can view departments" ON public.departments FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admin can manage departments" ON public.departments FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admin can update departments" ON public.departments FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admin can delete departments" ON public.departments FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- Health indicators
CREATE POLICY "Authenticated can view indicators" ON public.health_indicators FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admin can manage indicators" ON public.health_indicators FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admin can update indicators" ON public.health_indicators FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admin can delete indicators" ON public.health_indicators FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- Hospital plans
CREATE POLICY "Can view plans for accessible departments" ON public.hospital_plans FOR SELECT TO authenticated USING (public.can_access_department(auth.uid(), department_id));
CREATE POLICY "Admin/Officer can create plans" ON public.hospital_plans FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'data_officer'));
CREATE POLICY "Admin/Head can update plans" ON public.hospital_plans FOR UPDATE USING (public.has_role(auth.uid(), 'admin') OR (public.has_role(auth.uid(), 'department_head') AND public.can_access_department(auth.uid(), department_id)));
CREATE POLICY "Admin can delete plans" ON public.hospital_plans FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- Data uploads
CREATE POLICY "Can view uploads for accessible departments" ON public.data_uploads FOR SELECT TO authenticated USING (public.can_access_department(auth.uid(), department_id) OR uploaded_by = auth.uid());
CREATE POLICY "Officer can upload" ON public.data_uploads FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'data_officer'));
CREATE POLICY "Owner/Admin can update uploads" ON public.data_uploads FOR UPDATE USING (public.has_role(auth.uid(), 'admin') OR uploaded_by = auth.uid());
CREATE POLICY "Admin can delete uploads" ON public.data_uploads FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- Data quality analyses
CREATE POLICY "Can view quality analysis" ON public.data_quality_analyses FOR SELECT TO authenticated USING (public.can_access_department(auth.uid(), department_id));
CREATE POLICY "Officer/Admin can create analysis" ON public.data_quality_analyses FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'data_officer'));
CREATE POLICY "Admin can update analysis" ON public.data_quality_analyses FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admin can delete analysis" ON public.data_quality_analyses FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- Performance gap analyses
CREATE POLICY "Can view gap analysis" ON public.performance_gap_analyses FOR SELECT TO authenticated USING (public.can_access_department(auth.uid(), department_id));
CREATE POLICY "Officer/Admin can create gap analysis" ON public.performance_gap_analyses FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'data_officer'));
CREATE POLICY "Admin can update gap analysis" ON public.performance_gap_analyses FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admin can delete gap analysis" ON public.performance_gap_analyses FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- Reports
CREATE POLICY "Can view reports" ON public.reports FOR SELECT TO authenticated USING (public.can_access_department(auth.uid(), department_id) OR department_id IS NULL);
CREATE POLICY "Officer/Admin can create reports" ON public.reports FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'data_officer'));
CREATE POLICY "Admin/Head can update reports" ON public.reports FOR UPDATE USING (public.has_role(auth.uid(), 'admin') OR (public.has_role(auth.uid(), 'department_head') AND public.can_access_department(auth.uid(), department_id)));
CREATE POLICY "Admin can delete reports" ON public.reports FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- =============================================
-- Seed default departments
-- =============================================
INSERT INTO public.departments (name, description) VALUES
  ('Emergency', 'Emergency Department'),
  ('Outpatient', 'Outpatient Department (OPD)'),
  ('Inpatient', 'Inpatient Department (IPD)'),
  ('Maternity', 'Maternity & Reproductive Health'),
  ('Pediatrics', 'Pediatrics Department'),
  ('Surgery', 'Surgical Department'),
  ('Laboratory', 'Laboratory Services'),
  ('Pharmacy', 'Pharmacy Department'),
  ('Radiology', 'Radiology & Imaging'),
  ('Nutrition', 'Nutrition Department'),
  ('HIV/AIDS', 'HIV/AIDS Program'),
  ('TB', 'Tuberculosis Program'),
  ('Malaria', 'Malaria Program'),
  ('Immunization', 'Expanded Program on Immunization (EPI)'),
  ('HMIS', 'Health Management Information Systems');

-- Storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES ('uploads', 'uploads', false);
INSERT INTO storage.buckets (id, name, public) VALUES ('reports', 'reports', false);

-- Storage policies
CREATE POLICY "Authenticated users can upload files" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'uploads');
CREATE POLICY "Users can view uploaded files" ON storage.objects FOR SELECT TO authenticated USING (bucket_id IN ('uploads', 'reports'));
CREATE POLICY "Authenticated users can upload reports" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'reports');
