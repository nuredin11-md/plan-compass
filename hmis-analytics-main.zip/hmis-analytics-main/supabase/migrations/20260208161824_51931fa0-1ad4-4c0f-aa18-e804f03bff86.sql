
-- Create feedbacks table
CREATE TABLE public.feedbacks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  feedback_type TEXT NOT NULL DEFAULT 'monthly',
  department_id UUID REFERENCES public.departments(id),
  period_month INTEGER,
  period_year INTEGER NOT NULL,
  created_by UUID NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create feedback_replies table
CREATE TABLE public.feedback_replies (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  feedback_id UUID NOT NULL REFERENCES public.feedbacks(id) ON DELETE CASCADE,
  reply_content TEXT NOT NULL,
  replied_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.feedbacks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.feedback_replies ENABLE ROW LEVEL SECURITY;

-- Feedbacks policies
CREATE POLICY "Admins can do everything with feedbacks"
ON public.feedbacks FOR ALL
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can view shared feedbacks for their department"
ON public.feedbacks FOR SELECT
USING (
  status = 'shared' AND (
    department_id IS NULL OR
    public.get_user_department(auth.uid()) = department_id
  )
);

-- Feedback replies policies
CREATE POLICY "Authenticated can view replies for visible feedbacks"
ON public.feedback_replies FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.feedbacks f
    WHERE f.id = feedback_id AND (
      public.has_role(auth.uid(), 'admin') OR
      (f.status = 'shared' AND (f.department_id IS NULL OR public.get_user_department(auth.uid()) = f.department_id))
    )
  )
);

CREATE POLICY "Users can reply to visible feedbacks"
ON public.feedback_replies FOR INSERT
WITH CHECK (
  replied_by = auth.uid() AND
  EXISTS (
    SELECT 1 FROM public.feedbacks f
    WHERE f.id = feedback_id AND (
      public.has_role(auth.uid(), 'admin') OR
      (f.status = 'shared' AND (f.department_id IS NULL OR public.get_user_department(auth.uid()) = f.department_id))
    )
  )
);

CREATE POLICY "Admins can delete replies"
ON public.feedback_replies FOR DELETE
USING (public.has_role(auth.uid(), 'admin'));

-- Trigger for updated_at on feedbacks
CREATE TRIGGER update_feedbacks_updated_at
BEFORE UPDATE ON public.feedbacks
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();
