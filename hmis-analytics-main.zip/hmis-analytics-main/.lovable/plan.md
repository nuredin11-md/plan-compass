

# Dark Healthcare Theme + Admin Feedback System

## Overview
Redesign the entire app with a modern, dark healthcare-themed UI featuring data trend visuals, plus add a feedback system where admins can generate/share feedback and department heads can view and reply.

---

## Part 1: Dark Healthcare Theme Redesign

### 1.1 Color System (index.css)
- Switch the default (light) mode to a dark palette with deep blacks and dark grays
- Primary accent: cyan/teal (#0EA5E9 or similar) for a "health-tech" feel
- Secondary: emerald green for success/health indicators
- Accent: amber for warnings, red for critical
- Cards: dark glass-morphism with subtle borders and glow effects
- Background: near-black (#0A0A0F) with subtle gradient overlays

### 1.2 Sidebar (AppSidebar.tsx, MobileNav.tsx)
- Darker sidebar with subtle left-border accent on active items
- Add a subtle pulse/glow dot on the logo icon
- Healthcare-themed header with heartbeat/pulse icon styling
- Smooth hover transitions with cyan highlights

### 1.3 Auth Page (Auth.tsx)
- Full-screen dark background with subtle animated grid or data-flow pattern using CSS
- Glowing card with border gradient effect
- Healthcare branding with pulse/heartbeat visual

### 1.4 Dashboard (Dashboard.tsx)
- Stat cards with colored left borders and subtle gradient backgrounds
- Add a placeholder area chart (using recharts) showing "Performance Trend" with sample data
- Quick action buttons with icon glow effects on hover
- Recent activity sections with dark card styling

### 1.5 All Other Pages
- Apply consistent dark glass-card styling across DataUpload, HospitalPlans, DataQuality, Performance, Reports, Distribution, Admin
- Upload area with dashed border in cyan accent
- Data quality dimension cards with colored icon backgrounds

### 1.6 Global Styles
- Custom scrollbar styling (dark)
- Glow/pulse keyframe animations
- Glass-card utility updated for dark theme
- Subtle grid/dot background pattern via CSS

---

## Part 2: Feedback System (Admin generates, Users reply)

### 2.1 Database Migration
Create a new `feedbacks` table:
```text
feedbacks
  - id (uuid, PK)
  - title (text)
  - content (text) -- the feedback message
  - feedback_type (text) -- 'monthly' | 'quarterly' | 'annual'
  - department_id (uuid, nullable, FK to departments)
  - period_month (int, nullable)
  - period_year (int)
  - created_by (uuid) -- admin who created
  - status (text) -- 'draft' | 'shared'
  - created_at, updated_at (timestamptz)
```

Create a `feedback_replies` table:
```text
feedback_replies
  - id (uuid, PK)
  - feedback_id (uuid, FK to feedbacks)
  - reply_content (text)
  - replied_by (uuid)
  - created_at (timestamptz)
```

RLS policies:
- Admins can INSERT/UPDATE/DELETE feedbacks
- Users (department heads/viewers) can SELECT feedbacks shared with their department or all departments (department_id IS NULL)
- Users can INSERT replies to feedbacks they can view
- All authenticated users can SELECT replies for feedbacks they can see

### 2.2 New "Feedback" Page (src/pages/Feedback.tsx)
- Add route `/feedback` to App.tsx
- Add nav item in sidebar with MessageSquare icon

**Admin View:**
- List of all feedbacks with status badges (draft/shared)
- "Create Feedback" button opening a form/dialog with: title, content (rich text area), type (monthly/quarterly/annual), target department (or all), period
- "Share" action to change status from draft to shared
- View replies from department heads

**User View (Department Head / Viewer):**
- List of feedbacks shared with their department
- Click to expand and read full content
- Reply text area to respond to feedback
- View thread of replies

### 2.3 Sidebar Update
- Add "Feedback" nav item between Reports and Distribution
- Icon: MessageSquare from lucide-react

### 2.4 Admin Panel Enhancement
- Add a feedback summary card showing count of pending/shared feedbacks

---

## Files to Create
- `src/pages/Feedback.tsx` -- main feedback page with admin/user views

## Files to Modify
- `src/index.css` -- dark theme color variables and new utility classes
- `tailwind.config.ts` -- any additional animation keyframes
- `src/App.tsx` -- add /feedback route
- `src/components/layout/AppSidebar.tsx` -- add Feedback nav item
- `src/components/layout/MobileNav.tsx` -- add Feedback nav item
- `src/pages/Auth.tsx` -- dark themed auth page
- `src/pages/Dashboard.tsx` -- dark stat cards with trend chart
- `src/pages/DataUpload.tsx` -- dark styled upload area
- `src/pages/DataQuality.tsx` -- dark styled quality cards
- `src/pages/HospitalPlans.tsx` -- dark styling
- `src/pages/Performance.tsx` -- dark styling
- `src/pages/Reports.tsx` -- dark styling
- `src/pages/Distribution.tsx` -- dark styling
- `src/pages/Admin.tsx` -- dark styling + feedback summary card

## Database Migration
- Create `feedbacks` and `feedback_replies` tables with RLS policies
