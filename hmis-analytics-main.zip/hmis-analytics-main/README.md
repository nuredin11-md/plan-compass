# 🏥 Healthcare HMIS & M&E Analytics Platform
**Project Info**
# Project URL:
👉 https://github.com/aphninuredin-design/hmis-analytics

A modern healthcare data analytics platform designed to support HMIS (Health Management Information System) and Monitoring & Evaluation (M&E) teams in hospitals. The system enables real-time dashboards, automated reporting, data quality monitoring, and evidence-based decision-making to strengthen health system performance.

# 🎯 Project Purpose

# This platform helps hospitals and health institutions:

Track key HMIS & M&E indicators

Monitor service performance (ANC, Delivery, FP, EPI, Nutrition, NCDs)

Improve data quality and reporting accuracy

Support monthly, quarterly, and annual health reporting

Enable data-driven decision-making

# 🚀 Key Features

📊 Real-time performance dashboards

📈 HMIS & M&E indicator tracking

🧮 Automated analytics and reporting

🔍 Data quality validation & monitoring

🛡️ Secure role-based access (RLS)

🗄️ Supabase + PostgreSQL backend

📝 Feedback & performance monitoring module

🌙 Dark mode support

⚡ Fast and scalable UI

# Languages & Evidence:
TypeScript (92.1%) – core frontend logic with React and Vite. Verified via .ts / .tsx files and package.json dependencies.

PL/pgSQL (5.8%) – backend database functions in supabase/*.sql.

CSS (1.3%) – UI styling via Tailwind CSS.

Other (0.8%) – config and setup files.


# 👥 Target Users

HMIS Officers

Monitoring & Evaluation Teams

Hospital Managers & Administrators

Health Program Coordinators

Digital Health & Data Teams

# 💻 Technologies Used

This project is built with:

Vite

TypeScript

React

ShadCN UI

Tailwind CSS

Supabase

PostgreSQL (PL/pgSQL)

# 🧠 Example Use Cases

Monitor ANC early initiation & maternal health performance

Track immunization coverage and dropout rates

Evaluate family planning uptake

Assess nutrition and child health indicators

Support hospital performance review meetings

Improve data completeness and accuracy

# 🔐 Security & Data Protection

Secure authentication via Supabase

Role-based data access

Hospital-level data privacy

Designed to support health data confidentiality standards

# 📌 Project Tagline Options

Smarter Data for Stronger Health Systems

Turning Health Data into Action

Powering HMIS & M&E with Real-Time Intelligence

Modern Analytics for Hospital Performance

# 📬 Contact

Developer: Nuredin Mohammed
Role: Digital Health & M&E Specialist
Country: Ethiopia
