import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Shield, Users, Building2, MessageSquare } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";

export default function Admin() {
  const { data: feedbackCounts } = useQuery({
    queryKey: ["admin-feedback-counts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("feedbacks")
        .select("status");
      if (error) throw error;
      const draft = data?.filter((f: any) => f.status === "draft").length ?? 0;
      const shared = data?.filter((f: any) => f.status === "shared").length ?? 0;
      return { draft, shared, total: draft + shared };
    },
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Admin Panel</h1>
        <p className="text-muted-foreground">Manage users, roles, and departments.</p>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="glass-card border-l-4 border-l-primary">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2"><Users className="h-5 w-5 text-primary" />Users</CardTitle>
            <CardDescription>Manage hospital staff accounts</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">—</p>
            <p className="text-xs text-muted-foreground">Total registered users</p>
          </CardContent>
        </Card>
        <Card className="glass-card border-l-4 border-l-warning">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2"><Shield className="h-5 w-5 text-warning" />Roles</CardTitle>
            <CardDescription>Assign and manage user roles</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">Admin, Data Officer, Department Head, Viewer</p>
          </CardContent>
        </Card>
        <Card className="glass-card border-l-4 border-l-secondary">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2"><Building2 className="h-5 w-5 text-secondary" />Departments</CardTitle>
            <CardDescription>Hospital departments</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">15</p>
            <p className="text-xs text-muted-foreground">Configured departments</p>
          </CardContent>
        </Card>
        <Card className="glass-card border-l-4 border-l-info">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2"><MessageSquare className="h-5 w-5 text-info" />Feedback</CardTitle>
            <CardDescription>Admin feedback summary</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-3">
              <div>
                <p className="text-2xl font-bold">{feedbackCounts?.total ?? "—"}</p>
                <p className="text-xs text-muted-foreground">Total</p>
              </div>
              <div>
                <p className="text-lg font-semibold text-warning">{feedbackCounts?.draft ?? 0}</p>
                <p className="text-xs text-muted-foreground">Draft</p>
              </div>
              <div>
                <p className="text-lg font-semibold text-success">{feedbackCounts?.shared ?? 0}</p>
                <p className="text-xs text-muted-foreground">Shared</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
