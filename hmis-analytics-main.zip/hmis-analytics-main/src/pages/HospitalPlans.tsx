import { useState, useRef, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Plus, Target, Edit2, Trash2, Upload, Download, Loader2, FileSpreadsheet, AlertTriangle, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import * as XLSX from "xlsx";

const MONTHS = ["Annual", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export default function HospitalPlans() {
  const { user, hasRole, isAdmin } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canEdit = isAdmin || hasRole("data_officer") || hasRole("department_head");

  const [editingPlan, setEditingPlan] = useState<any>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [importStep, setImportStep] = useState<"idle" | "preview" | "importing" | "done">("idle");
  const [importData, setImportData] = useState<any[]>([]);
  const [importErrors, setImportErrors] = useState<string[]>([]);
  const [importProgress, setImportProgress] = useState(0);

  const [form, setForm] = useState({
    department_id: "", indicator_id: "", year: new Date().getFullYear().toString(),
    month: "", target_value: "",
  });

  const { data: departments } = useQuery({
    queryKey: ["departments"],
    queryFn: async () => {
      const { data, error } = await supabase.from("departments").select("*").order("name");
      if (error) throw error;
      return data;
    },
  });

  const { data: indicators } = useQuery({
    queryKey: ["health-indicators"],
    queryFn: async () => {
      const { data, error } = await supabase.from("health_indicators").select("*").order("name");
      if (error) throw error;
      return data;
    },
  });

  const { data: plans, isLoading } = useQuery({
    queryKey: ["hospital-plans"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("hospital_plans")
        .select("*, departments(name), health_indicators(name, unit)")
        .order("year", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (values: any) => {
      if (editingPlan) {
        const { error } = await supabase.from("hospital_plans").update({
          department_id: values.department_id,
          indicator_id: values.indicator_id,
          year: parseInt(values.year),
          month: values.month ? parseInt(values.month) : null,
          target_value: parseFloat(values.target_value),
        }).eq("id", editingPlan.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("hospital_plans").insert({
          department_id: values.department_id,
          indicator_id: values.indicator_id,
          year: parseInt(values.year),
          month: values.month ? parseInt(values.month) : null,
          target_value: parseFloat(values.target_value),
          created_by: user?.id,
        });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast({ title: editingPlan ? "Plan updated" : "Plan created" });
      queryClient.invalidateQueries({ queryKey: ["hospital-plans"] });
      resetForm();
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("hospital_plans").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Plan deleted" });
      queryClient.invalidateQueries({ queryKey: ["hospital-plans"] });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const resetForm = () => {
    setForm({ department_id: "", indicator_id: "", year: new Date().getFullYear().toString(), month: "", target_value: "" });
    setEditingPlan(null);
    setFormOpen(false);
  };

  const openEdit = (plan: any) => {
    setEditingPlan(plan);
    setForm({
      department_id: plan.department_id,
      indicator_id: plan.indicator_id,
      year: String(plan.year),
      month: plan.month ? String(plan.month) : "",
      target_value: String(plan.target_value),
    });
    setFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.department_id || !form.indicator_id || !form.target_value) {
      toast({ title: "Missing fields", variant: "destructive" });
      return;
    }
    saveMutation.mutate(form);
  };

  // --- Import from file ---
  const parseImportFile = useCallback(async (file: File) => {
    try {
      const buffer = await file.arrayBuffer();
      const wb = XLSX.read(buffer, { type: "array" });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json<any>(sheet, { defval: null });

      if (rows.length === 0) {
        setImportErrors(["File is empty."]);
        return;
      }

      // Validate required columns
      const requiredCols = ["department", "indicator", "year", "target_value"];
      const headers = Object.keys(rows[0]).map(h => h.toLowerCase().trim());
      const missing = requiredCols.filter(c => !headers.some(h => h.includes(c)));
      const errors: string[] = [];
      if (missing.length) errors.push(`Missing columns: ${missing.join(", ")}. Required: department, indicator, year, target_value`);

      setImportData(rows);
      setImportErrors(errors);
      setImportStep("preview");
    } catch (e: any) {
      setImportErrors([e.message]);
    }
  }, []);

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) parseImportFile(file);
    e.target.value = "";
  };

  const executeImport = async () => {
    if (!user || !departments || !indicators) return;
    setImportStep("importing");
    setImportProgress(0);

    const deptMap = new Map(departments.map(d => [d.name.toLowerCase().trim(), d.id]));
    const indMap = new Map(indicators.map(i => [i.name.toLowerCase().trim(), i.id]));

    const validRows: any[] = [];
    const rowErrors: string[] = [];

    importData.forEach((row, idx) => {
      const deptKey = String(row.department || row.Department || "").toLowerCase().trim();
      const indKey = String(row.indicator || row.Indicator || "").toLowerCase().trim();
      const year = parseInt(String(row.year || row.Year || ""));
      const target = parseFloat(String(row.target_value || row["Target Value"] || row.target || ""));
      const month = row.month || row.Month;

      const deptId = deptMap.get(deptKey);
      const indId = indMap.get(indKey);

      if (!deptId) { rowErrors.push(`Row ${idx + 2}: Unknown department "${deptKey}"`); return; }
      if (!indId) { rowErrors.push(`Row ${idx + 2}: Unknown indicator "${indKey}"`); return; }
      if (isNaN(year)) { rowErrors.push(`Row ${idx + 2}: Invalid year`); return; }
      if (isNaN(target)) { rowErrors.push(`Row ${idx + 2}: Invalid target value`); return; }

      validRows.push({
        department_id: deptId,
        indicator_id: indId,
        year,
        month: month ? parseInt(String(month)) : null,
        target_value: target,
        created_by: user.id,
      });
    });

    if (rowErrors.length > 0 && validRows.length === 0) {
      setImportErrors(rowErrors);
      setImportStep("preview");
      return;
    }

    // Batch insert
    const BATCH_SIZE = 100;
    let imported = 0;
    for (let i = 0; i < validRows.length; i += BATCH_SIZE) {
      const batch = validRows.slice(i, i + BATCH_SIZE);
      const { error } = await supabase.from("hospital_plans").upsert(batch, {
        onConflict: "department_id,indicator_id,year,month",
        ignoreDuplicates: false,
      });
      if (error) {
        // Fallback to insert if upsert fails (no unique constraint)
        const { error: insertErr } = await supabase.from("hospital_plans").insert(batch);
        if (insertErr) {
          rowErrors.push(`Batch starting row ${i + 2}: ${insertErr.message}`);
        }
      }
      imported += batch.length;
      setImportProgress(Math.round((imported / validRows.length) * 100));
      await new Promise(r => setTimeout(r, 50));
    }

    setImportErrors(rowErrors);
    setImportStep("done");
    toast({ title: "Import complete", description: `${imported} plans imported. ${rowErrors.length} errors.` });
    queryClient.invalidateQueries({ queryKey: ["hospital-plans"] });
  };

  const handleExport = () => {
    if (!plans?.length) return;
    const ws = XLSX.utils.json_to_sheet(plans.map((p: any) => ({
      Department: p.departments?.name || "",
      Indicator: p.health_indicators?.name || "",
      Year: p.year,
      Month: p.month || "Annual",
      "Target Value": p.target_value,
      Unit: p.health_indicators?.unit || "",
    })));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Plans");
    XLSX.writeFile(wb, `hospital_plans_${new Date().getFullYear()}.xlsx`);
    toast({ title: "Exported successfully" });
  };

  const resetImport = () => {
    setImportStep("idle");
    setImportData([]);
    setImportErrors([]);
    setImportProgress(0);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Hospital Plans & Targets</h1>
          <p className="text-muted-foreground">Manage annual and monthly performance targets by department.</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {canEdit && (
            <>
              <input ref={fileInputRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleImportFile} />
              <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                <Upload className="mr-2 h-4 w-4" />Import Plan
              </Button>
            </>
          )}
          <Button variant="outline" onClick={handleExport} disabled={!plans?.length}>
            <Download className="mr-2 h-4 w-4" />Export
          </Button>
          {canEdit && (
            <Dialog open={formOpen} onOpenChange={(o) => { if (!o) resetForm(); else setFormOpen(true); }}>
              <DialogTrigger asChild>
                <Button><Plus className="mr-2 h-4 w-4" />Add Plan</Button>
              </DialogTrigger>
              <DialogContent className="bg-card border-border">
                <DialogHeader>
                  <DialogTitle>{editingPlan ? "Edit Plan" : "Add New Plan"}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label>Department</Label>
                    <Select value={form.department_id} onValueChange={v => setForm(f => ({ ...f, department_id: v }))}>
                      <SelectTrigger className="bg-muted/50"><SelectValue placeholder="Select department" /></SelectTrigger>
                      <SelectContent>
                        {departments?.map(d => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Health Indicator</Label>
                    <Select value={form.indicator_id} onValueChange={v => setForm(f => ({ ...f, indicator_id: v }))}>
                      <SelectTrigger className="bg-muted/50"><SelectValue placeholder="Select indicator" /></SelectTrigger>
                      <SelectContent>
                        {indicators?.map(i => <SelectItem key={i.id} value={i.id}>{i.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label>Year</Label>
                      <Input type="number" value={form.year} onChange={e => setForm(f => ({ ...f, year: e.target.value }))} className="bg-muted/50" />
                    </div>
                    <div className="space-y-2">
                      <Label>Month (optional)</Label>
                      <Select value={form.month || "annual"} onValueChange={v => setForm(f => ({ ...f, month: v === "annual" ? "" : v }))}>
                        <SelectTrigger className="bg-muted/50"><SelectValue placeholder="Annual" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="annual">Annual</SelectItem>
                          {[...Array(12)].map((_, i) => <SelectItem key={i + 1} value={String(i + 1)}>{MONTHS[i + 1]}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Target Value</Label>
                    <Input type="number" step="any" value={form.target_value} onChange={e => setForm(f => ({ ...f, target_value: e.target.value }))} placeholder="e.g. 95" className="bg-muted/50" />
                  </div>
                  <DialogFooter>
                    <DialogClose asChild><Button variant="outline" type="button">Cancel</Button></DialogClose>
                    <Button type="submit" disabled={saveMutation.isPending}>
                      {saveMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      {editingPlan ? "Update" : "Create"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      {/* Import Preview */}
      {importStep === "preview" && (
        <Card className="glass-card border-primary/30">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <FileSpreadsheet className="h-5 w-5 text-primary" />Import Preview
            </CardTitle>
            <CardDescription>{importData.length} rows found</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {importErrors.length > 0 && (
              <div className="rounded-md bg-warning/10 border border-warning/30 p-3 space-y-1">
                {importErrors.slice(0, 10).map((e, i) => (
                  <p key={i} className="text-sm text-warning flex items-center gap-2">
                    <AlertTriangle className="h-3 w-3 shrink-0" />{e}
                  </p>
                ))}
                {importErrors.length > 10 && <p className="text-xs text-warning">...and {importErrors.length - 10} more</p>}
              </div>
            )}
            <div className="overflow-x-auto rounded-md border border-border max-h-48">
              <table className="w-full text-xs">
                <thead className="bg-muted/50 sticky top-0">
                  <tr>
                    {importData[0] && Object.keys(importData[0]).slice(0, 6).map(h => (
                      <th key={h} className="px-2 py-1.5 text-left text-muted-foreground">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {importData.slice(0, 5).map((row, i) => (
                    <tr key={i} className="border-t border-border/50">
                      {Object.values(row).slice(0, 6).map((v, j) => (
                        <td key={j} className="px-2 py-1 truncate max-w-[100px]">{String(v ?? "")}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={resetImport}>Cancel</Button>
              <Button onClick={executeImport} disabled={importErrors.some(e => e.includes("Missing columns"))}>
                <Upload className="mr-2 h-4 w-4" />Import {importData.length} Plans
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {importStep === "importing" && (
        <Card className="glass-card">
          <CardContent className="py-8 flex flex-col items-center gap-3">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
            <p className="text-sm">Importing plans...</p>
            <div className="w-48"><div className="h-2 bg-muted rounded-full overflow-hidden"><div className="h-full bg-primary transition-all" style={{ width: `${importProgress}%` }} /></div></div>
          </CardContent>
        </Card>
      )}

      {importStep === "done" && (
        <Card className="glass-card border-success/30">
          <CardContent className="py-8 flex flex-col items-center gap-3">
            <CheckCircle className="h-10 w-10 text-success" />
            <p className="font-semibold">Import Complete!</p>
            {importErrors.length > 0 && <p className="text-sm text-warning">{importErrors.length} rows had errors</p>}
            <Button onClick={resetImport}>Done</Button>
          </CardContent>
        </Card>
      )}

      {/* Plans Table */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />Current Plans
          </CardTitle>
          <CardDescription>Targets organized by department and year</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-6"><Loader2 className="h-5 w-5 animate-spin text-primary" /></div>
          ) : !plans?.length ? (
            <p className="text-sm text-muted-foreground">No plans configured yet. Add your first plan or import from a file.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 text-muted-foreground font-medium">Department</th>
                    <th className="text-left py-2 text-muted-foreground font-medium">Indicator</th>
                    <th className="text-left py-2 text-muted-foreground font-medium">Year</th>
                    <th className="text-left py-2 text-muted-foreground font-medium">Period</th>
                    <th className="text-right py-2 text-muted-foreground font-medium">Target</th>
                    {canEdit && <th className="text-right py-2 text-muted-foreground font-medium">Actions</th>}
                  </tr>
                </thead>
                <tbody>
                  {plans.map((p: any) => (
                    <tr key={p.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                      <td className="py-2">{p.departments?.name || "—"}</td>
                      <td className="py-2">{p.health_indicators?.name || "—"}</td>
                      <td className="py-2">{p.year}</td>
                      <td className="py-2">{p.month ? MONTHS[p.month] : "Annual"}</td>
                      <td className="py-2 text-right font-mono">{p.target_value} {p.health_indicators?.unit || ""}</td>
                      {canEdit && (
                        <td className="py-2 text-right">
                          <div className="flex gap-1 justify-end">
                            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(p)}>
                              <Edit2 className="h-3.5 w-3.5" />
                            </Button>
                            {isAdmin && (
                              <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive"
                                onClick={() => { if (confirm("Delete this plan?")) deleteMutation.mutate(p.id); }}>
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            )}
                          </div>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
