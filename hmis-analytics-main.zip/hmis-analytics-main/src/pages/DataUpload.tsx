import { useState, useRef, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Upload, FileSpreadsheet, FileText, Download, Trash2, CheckCircle, AlertTriangle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import * as XLSX from "xlsx";

interface ParsedRow {
  [key: string]: string | number | null;
}

interface UploadState {
  file: File | null;
  parsedData: ParsedRow[];
  headers: string[];
  errors: string[];
  uploading: boolean;
  progress: number;
  step: "idle" | "preview" | "uploading" | "done";
}

export default function DataUpload() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [state, setState] = useState<UploadState>({
    file: null, parsedData: [], headers: [], errors: [], uploading: false, progress: 0, step: "idle",
  });

  const { data: uploads, isLoading: uploadsLoading } = useQuery({
    queryKey: ["data-uploads"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("data_uploads")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(20);
      if (error) throw error;
      return data;
    },
  });

  const parseFile = useCallback(async (file: File) => {
    try {
      const ext = file.name.split(".").pop()?.toLowerCase();
      if (!["xlsx", "xls", "csv"].includes(ext || "")) {
        setState(s => ({ ...s, errors: ["Unsupported file type. Use .xlsx, .xls, or .csv"] }));
        return;
      }

      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: "array" });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json<ParsedRow>(sheet, { defval: null });

      if (jsonData.length === 0) {
        setState(s => ({ ...s, errors: ["File is empty or has no data rows."] }));
        return;
      }

      const headers = Object.keys(jsonData[0]);
      const errors: string[] = [];
      if (jsonData.length > 10000) errors.push("Large file: processing may take a moment.");

      setState(s => ({
        ...s,
        file,
        parsedData: jsonData,
        headers,
        errors,
        step: "preview",
      }));
    } catch (e: any) {
      setState(s => ({ ...s, errors: [e.message || "Failed to parse file."] }));
    }
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 20 * 1024 * 1024) {
        toast({ title: "File too large", description: "Maximum file size is 20MB.", variant: "destructive" });
        return;
      }
      parseFile(file);
    }
    e.target.value = "";
  };

  const handleUpload = async () => {
    if (!state.file || !user) return;
    setState(s => ({ ...s, uploading: true, step: "uploading", progress: 0 }));

    try {
      // 1. Upload file to storage
      const filePath = `${user.id}/${Date.now()}_${state.file.name}`;
      const { error: storageError } = await supabase.storage
        .from("uploads")
        .upload(filePath, state.file);
      if (storageError) throw storageError;

      setState(s => ({ ...s, progress: 40 }));

      // 2. Insert record into data_uploads
      const { error: dbError } = await supabase.from("data_uploads").insert({
        file_name: state.file.name,
        file_path: filePath,
        file_type: state.file.name.split(".").pop() || "unknown",
        file_size: state.file.size,
        uploaded_by: user.id,
        status: "processed",
        parsed_data: state.parsedData.slice(0, 500) as any, // store first 500 rows as preview
      });
      if (dbError) throw dbError;

      setState(s => ({ ...s, progress: 100, step: "done" }));
      toast({ title: "Upload successful!", description: `${state.file.name} uploaded with ${state.parsedData.length} rows.` });
      queryClient.invalidateQueries({ queryKey: ["data-uploads"] });
    } catch (e: any) {
      toast({ title: "Upload failed", description: e.message, variant: "destructive" });
      setState(s => ({ ...s, uploading: false, step: "preview" }));
    }
  };

  const handleExport = async () => {
    if (!uploads || uploads.length === 0) {
      toast({ title: "Nothing to export", variant: "destructive" });
      return;
    }
    const ws = XLSX.utils.json_to_sheet(uploads.map(u => ({
      "File Name": u.file_name,
      "Type": u.file_type,
      "Status": u.status,
      "Uploaded At": new Date(u.created_at).toLocaleDateString(),
      "Size (KB)": u.file_size ? Math.round(u.file_size / 1024) : "—",
    })));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Uploads");
    XLSX.writeFile(wb, "data_uploads_export.xlsx");
    toast({ title: "Exported successfully" });
  };

  const resetUpload = () => {
    setState({ file: null, parsedData: [], headers: [], errors: [], uploading: false, progress: 0, step: "idle" });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Data Upload</h1>
          <p className="text-muted-foreground">Upload DHIS2 or other health data files for analysis.</p>
        </div>
        <Button variant="outline" onClick={handleExport} disabled={!uploads?.length}>
          <Download className="mr-2 h-4 w-4" />Export History
        </Button>
      </div>

      <input ref={fileInputRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleFileSelect} />

      {state.step === "idle" && (
        <Card className="glass-card border-dashed border-primary/30 cursor-pointer hover:border-primary/60 transition-colors"
          onClick={() => fileInputRef.current?.click()}>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
              <Upload className="h-8 w-8 text-primary" />
            </div>
            <h3 className="mb-1 text-lg font-semibold">Drop files here or click to upload</h3>
            <p className="mb-4 text-sm text-muted-foreground">Supports Excel (.xlsx, .xls) and CSV files up to 20MB</p>
            <div className="flex gap-2">
              <Button onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}>
                <FileSpreadsheet className="mr-2 h-4 w-4" />Upload Excel/CSV
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {state.step === "preview" && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              Preview: {state.file?.name}
            </CardTitle>
            <CardDescription>{state.parsedData.length} rows, {state.headers.length} columns detected</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {state.errors.length > 0 && (
              <div className="rounded-md bg-warning/10 border border-warning/30 p-3">
                {state.errors.map((err, i) => (
                  <p key={i} className="text-sm text-warning flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />{err}
                  </p>
                ))}
              </div>
            )}

            <div className="overflow-x-auto rounded-md border border-border max-h-64">
              <table className="w-full text-xs">
                <thead className="bg-muted/50 sticky top-0">
                  <tr>
                    <th className="px-2 py-1.5 text-left text-muted-foreground">#</th>
                    {state.headers.slice(0, 8).map(h => (
                      <th key={h} className="px-2 py-1.5 text-left text-muted-foreground truncate max-w-[120px]">{h}</th>
                    ))}
                    {state.headers.length > 8 && <th className="px-2 py-1.5 text-muted-foreground">+{state.headers.length - 8} more</th>}
                  </tr>
                </thead>
                <tbody>
                  {state.parsedData.slice(0, 10).map((row, i) => (
                    <tr key={i} className="border-t border-border/50">
                      <td className="px-2 py-1 text-muted-foreground">{i + 1}</td>
                      {state.headers.slice(0, 8).map(h => (
                        <td key={h} className="px-2 py-1 truncate max-w-[120px]">{String(row[h] ?? "")}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={resetUpload}><Trash2 className="mr-2 h-4 w-4" />Cancel</Button>
              <Button onClick={handleUpload}><Upload className="mr-2 h-4 w-4" />Confirm Upload</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {state.step === "uploading" && (
        <Card className="glass-card">
          <CardContent className="py-12 flex flex-col items-center gap-4">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-sm text-muted-foreground">Uploading {state.file?.name}...</p>
            <Progress value={state.progress} className="w-64" />
          </CardContent>
        </Card>
      )}

      {state.step === "done" && (
        <Card className="glass-card border-success/30">
          <CardContent className="py-12 flex flex-col items-center gap-4">
            <CheckCircle className="h-12 w-12 text-success" />
            <p className="text-lg font-semibold">Upload Complete!</p>
            <p className="text-sm text-muted-foreground">{state.parsedData.length} rows processed from {state.file?.name}</p>
            <Button onClick={resetUpload}>Upload Another File</Button>
          </CardContent>
        </Card>
      )}

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-base">Upload History</CardTitle>
          <CardDescription>Previously uploaded datasets</CardDescription>
        </CardHeader>
        <CardContent>
          {uploadsLoading ? (
            <div className="flex justify-center py-4"><Loader2 className="h-5 w-5 animate-spin text-primary" /></div>
          ) : !uploads?.length ? (
            <p className="text-sm text-muted-foreground">No uploads yet.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 text-muted-foreground font-medium">File</th>
                    <th className="text-left py-2 text-muted-foreground font-medium">Type</th>
                    <th className="text-left py-2 text-muted-foreground font-medium">Status</th>
                    <th className="text-left py-2 text-muted-foreground font-medium">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {uploads.map(u => (
                    <tr key={u.id} className="border-b border-border/50">
                      <td className="py-2">{u.file_name}</td>
                      <td className="py-2 uppercase text-xs">{u.file_type}</td>
                      <td className="py-2">
                        <span className={`text-xs px-2 py-0.5 rounded-full ${u.status === 'processed' ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'}`}>
                          {u.status}
                        </span>
                      </td>
                      <td className="py-2 text-muted-foreground text-xs">{new Date(u.created_at).toLocaleDateString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
