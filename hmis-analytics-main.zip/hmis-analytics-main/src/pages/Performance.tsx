import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { TrendingUp } from "lucide-react";

export default function Performance() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Performance Gap Analysis</h1>
        <p className="text-muted-foreground">Compare actual performance against hospital targets.</p>
      </div>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><TrendingUp className="h-5 w-5 text-primary" />Gap Analysis</CardTitle>
          <CardDescription>Set targets and upload data to identify performance gaps.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">No gap analysis available. Ensure both targets and actual data are uploaded.</p>
        </CardContent>
      </Card>
    </div>
  );
}
