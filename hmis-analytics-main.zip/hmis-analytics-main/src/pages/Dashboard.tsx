import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Upload, Target, CheckCircle, TrendingUp, FileText, BarChart3, AlertTriangle, Clock } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const statCards = [
  { title: "Data Completeness", value: "—", icon: CheckCircle, color: "text-success", borderColor: "border-l-success" },
  { title: "Timeliness Score", value: "—", icon: Clock, color: "text-info", borderColor: "border-l-info" },
  { title: "Performance Score", value: "—", icon: TrendingUp, color: "text-primary", borderColor: "border-l-primary" },
  { title: "Active Gaps", value: "—", icon: AlertTriangle, color: "text-warning", borderColor: "border-l-warning" },
];

const quickActions = [
  { label: "Upload Data", path: "/data-upload", icon: Upload },
  { label: "Set Targets", path: "/hospital-plans", icon: Target },
  { label: "View Reports", path: "/reports", icon: FileText },
  { label: "Run Analysis", path: "/data-quality", icon: BarChart3 },
];

const trendData = [
  { month: "Jul", score: 62 },
  { month: "Aug", score: 68 },
  { month: "Sep", score: 65 },
  { month: "Oct", score: 74 },
  { month: "Nov", score: 78 },
  { month: "Dec", score: 82 },
  { month: "Jan", score: 80 },
  { month: "Feb", score: 85 },
];

export default function Dashboard() {
  const { profile } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Welcome back, {profile?.full_name || "User"}</h1>
        <p className="text-muted-foreground">Here's an overview of your HMIS & M&E metrics.</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {statCards.map((card) => (
          <Card key={card.title} className={`glass-card border-l-4 ${card.borderColor}`}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{card.title}</CardTitle>
              <card.icon className={`h-5 w-5 ${card.color}`} />
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{card.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Performance Trend Chart */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            Performance Trend
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={trendData}>
              <defs>
                <linearGradient id="trendGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(199 89% 48%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(199 89% 48%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(230 12% 16%)" />
              <XAxis dataKey="month" stroke="hsl(215 14% 55%)" fontSize={12} />
              <YAxis stroke="hsl(215 14% 55%)" fontSize={12} />
              <Tooltip
                contentStyle={{ backgroundColor: "hsl(230 15% 10%)", border: "1px solid hsl(230 12% 20%)", borderRadius: "8px", color: "hsl(210 20% 90%)" }}
              />
              <Area type="monotone" dataKey="score" stroke="hsl(199 89% 48%)" fillOpacity={1} fill="url(#trendGrad)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div>
        <h2 className="mb-3 text-lg font-semibold">Quick Actions</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {quickActions.map((action) => (
            <Button key={action.path} variant="outline" className="h-auto flex-col gap-2 py-6 glass-card hover:border-primary/50 transition-all" onClick={() => navigate(action.path)}>
              <action.icon className="h-6 w-6 text-primary" />
              <span className="text-xs">{action.label}</span>
            </Button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card className="glass-card">
          <CardHeader><CardTitle className="text-base">Recent Uploads</CardTitle></CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">No uploads yet. Start by uploading DHIS2 data.</p>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardHeader><CardTitle className="text-base">Recent Reports</CardTitle></CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">No reports generated yet.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
