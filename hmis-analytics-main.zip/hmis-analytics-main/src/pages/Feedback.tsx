import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Plus, Send, MessageSquare, Loader2 } from "lucide-react";

interface Feedback {
  id: string;
  title: string;
  content: string;
  feedback_type: string;
  department_id: string | null;
  period_month: number | null;
  period_year: number;
  created_by: string;
  status: string;
  created_at: string;
}

interface FeedbackReply {
  id: string;
  feedback_id: string;
  reply_content: string;
  replied_by: string;
  created_at: string;
}

export default function Feedback() {
  const { user, isAdmin } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState("");

  // Form state
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [feedbackType, setFeedbackType] = useState("monthly");
  const [deptId, setDeptId] = useState<string>("all");
  const [periodYear, setPeriodYear] = useState(new Date().getFullYear());
  const [periodMonth, setPeriodMonth] = useState<number | null>(null);

  const { data: departments } = useQuery({
    queryKey: ["departments"],
    queryFn: async () => {
      const { data, error } = await supabase.from("departments").select("id, name").order("name");
      if (error) throw error;
      return data;
    },
  });

  const { data: feedbacks, isLoading } = useQuery({
    queryKey: ["feedbacks"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("feedbacks")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Feedback[];
    },
  });

  const { data: replies } = useQuery({
    queryKey: ["feedback-replies"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("feedback_replies")
        .select("*")
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data as FeedbackReply[];
    },
  });

  const createMutation = useMutation({
    mutationFn: async (status: string) => {
      const { error } = await supabase.from("feedbacks").insert({
        title,
        content,
        feedback_type: feedbackType,
        department_id: deptId === "all" ? null : deptId,
        period_year: periodYear,
        period_month: periodMonth,
        created_by: user!.id,
        status,
      });
      if (error) throw error;
    },
    onSuccess: (_, status) => {
      queryClient.invalidateQueries({ queryKey: ["feedbacks"] });
      setDialogOpen(false);
      resetForm();
      toast({ title: status === "shared" ? "Feedback shared!" : "Draft saved." });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const shareMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("feedbacks").update({ status: "shared" }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["feedbacks"] });
      toast({ title: "Feedback shared!" });
    },
  });

  const replyMutation = useMutation({
    mutationFn: async (feedbackId: string) => {
      const { error } = await supabase.from("feedback_replies").insert({
        feedback_id: feedbackId,
        reply_content: replyText,
        replied_by: user!.id,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["feedback-replies"] });
      setReplyText("");
      toast({ title: "Reply sent!" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const resetForm = () => {
    setTitle(""); setContent(""); setFeedbackType("monthly"); setDeptId("all");
    setPeriodYear(new Date().getFullYear()); setPeriodMonth(null);
  };

  const getDeptName = (id: string | null) => {
    if (!id) return "All Departments";
    return departments?.find((d) => d.id === id)?.name ?? "Unknown";
  };

  const feedbackReplies = (fId: string) => replies?.filter((r) => r.feedback_id === fId) ?? [];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Feedback</h1>
          <p className="text-muted-foreground">
            {isAdmin ? "Create and share performance feedback with departments." : "View feedback from administration and reply."}
          </p>
        </div>
        {isAdmin && (
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button><Plus className="mr-2 h-4 w-4" />Create Feedback</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>Create Feedback</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Title</Label>
                  <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Monthly Performance Review" />
                </div>
                <div className="space-y-2">
                  <Label>Content</Label>
                  <Textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="Detailed feedback..." rows={5} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Type</Label>
                    <Select value={feedbackType} onValueChange={setFeedbackType}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="monthly">Monthly</SelectItem>
                        <SelectItem value="quarterly">Quarterly</SelectItem>
                        <SelectItem value="annual">Annual</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Department</Label>
                    <Select value={deptId} onValueChange={setDeptId}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Departments</SelectItem>
                        {departments?.map((d) => (
                          <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Year</Label>
                    <Input type="number" value={periodYear} onChange={(e) => setPeriodYear(Number(e.target.value))} />
                  </div>
                  <div className="space-y-2">
                    <Label>Month (optional)</Label>
                    <Input type="number" min={1} max={12} value={periodMonth ?? ""} onChange={(e) => setPeriodMonth(e.target.value ? Number(e.target.value) : null)} placeholder="1-12" />
                  </div>
                </div>
                <div className="flex gap-2 justify-end">
                  <Button variant="outline" onClick={() => createMutation.mutate("draft")} disabled={!title || !content || createMutation.isPending}>
                    Save Draft
                  </Button>
                  <Button onClick={() => createMutation.mutate("shared")} disabled={!title || !content || createMutation.isPending}>
                    <Send className="mr-2 h-4 w-4" />Share Now
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
      ) : !feedbacks?.length ? (
        <Card className="glass-card">
          <CardContent className="py-12 text-center">
            <MessageSquare className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
            <p className="text-muted-foreground">No feedback available yet.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {feedbacks.map((fb) => (
            <Card key={fb.id} className="glass-card">
              <CardHeader className="cursor-pointer" onClick={() => setExpandedId(expandedId === fb.id ? null : fb.id)}>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-base">{fb.title}</CardTitle>
                    <CardDescription className="mt-1">
                      {getDeptName(fb.department_id)} · {fb.feedback_type} · {fb.period_month ? `${fb.period_month}/` : ""}{fb.period_year}
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={fb.status === "shared" ? "default" : "secondary"}>
                      {fb.status}
                    </Badge>
                    {isAdmin && fb.status === "draft" && (
                      <Button size="sm" variant="outline" onClick={(e) => { e.stopPropagation(); shareMutation.mutate(fb.id); }}>
                        <Send className="mr-1 h-3 w-3" />Share
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>

              {expandedId === fb.id && (
                <CardContent className="pt-0">
                  <div className="rounded-md bg-muted/30 p-4 mb-4">
                    <p className="text-sm whitespace-pre-wrap">{fb.content}</p>
                  </div>

                  {/* Replies */}
                  <div className="space-y-3">
                    <h4 className="text-sm font-semibold text-muted-foreground">Replies ({feedbackReplies(fb.id).length})</h4>
                    {feedbackReplies(fb.id).map((r) => (
                      <div key={r.id} className="rounded-md bg-muted/20 p-3 border border-border/30">
                        <p className="text-sm">{r.reply_content}</p>
                        <p className="text-xs text-muted-foreground mt-1">{new Date(r.created_at).toLocaleDateString()}</p>
                      </div>
                    ))}
                    <Separator />
                    <div className="flex gap-2">
                      <Textarea
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                        placeholder="Write a reply..."
                        rows={2}
                        className="flex-1"
                      />
                      <Button
                        size="sm"
                        className="self-end"
                        disabled={!replyText.trim() || replyMutation.isPending}
                        onClick={() => replyMutation.mutate(fb.id)}
                      >
                        Reply
                      </Button>
                    </div>
                  </div>
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
