import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Send, MessageCircle } from "lucide-react";

export default function Distribution() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Report Distribution</h1>
        <p className="text-muted-foreground">Share reports via Telegram and WhatsApp.</p>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2"><Send className="h-5 w-5 text-info" />Telegram</CardTitle>
            <CardDescription>Send reports to Telegram groups</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">Connect your Telegram bot to start sharing reports.</p>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2"><MessageCircle className="h-5 w-5 text-success" />WhatsApp</CardTitle>
            <CardDescription>Share reports via WhatsApp</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">Configure WhatsApp integration to share reports.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
