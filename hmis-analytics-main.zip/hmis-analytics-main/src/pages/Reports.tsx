import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Plus } from "lucide-react";

export default function Reports() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Reports</h1>
          <p className="text-muted-foreground">Generate and export performance reports.</p>
        </div>
        <Button><Plus className="mr-2 h-4 w-4" />Generate Report</Button>
      </div>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><FileText className="h-5 w-5 text-primary" />Generated Reports</CardTitle>
          <CardDescription>Monthly, quarterly, and annual performance reports</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">No reports generated yet.</p>
        </CardContent>
      </Card>
    </div>
  );
}
