import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import {
  LayoutDashboard, Upload, Target, CheckCircle, TrendingUp, FileText, Send, Shield, LogOut, Activity, Menu, MessageSquare,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import { useState } from "react";

const navItems = [
  { path: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { path: "/data-upload", label: "Data Upload", icon: Upload },
  { path: "/hospital-plans", label: "Hospital Plans", icon: Target },
  { path: "/data-quality", label: "Data Quality", icon: CheckCircle },
  { path: "/performance", label: "Performance", icon: TrendingUp },
  { path: "/reports", label: "Reports", icon: FileText },
  { path: "/feedback", label: "Feedback", icon: MessageSquare },
  { path: "/distribution", label: "Distribution", icon: Send },
];

export default function MobileNav() {
  const navigate = useNavigate();
  const location = useLocation();
  const { isAdmin, signOut } = useAuth();
  const [open, setOpen] = useState(false);

  const go = (path: string) => { navigate(path); setOpen(false); };

  return (
    <header className="md:hidden flex items-center justify-between border-b border-border bg-card px-4 py-3">
      <div className="flex items-center gap-2">
        <div className="flex h-7 w-7 items-center justify-center rounded-md bg-primary animate-glow-pulse">
          <Activity className="h-4 w-4 text-primary-foreground" />
        </div>
        <span className="text-sm font-bold">HMIS Analytics</span>
      </div>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon"><Menu className="h-5 w-5" /></Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-64 p-0 bg-sidebar text-sidebar-foreground">
          <div className="px-5 py-5">
            <h1 className="text-sm font-bold">HMIS Analytics</h1>
          </div>
          <Separator className="bg-sidebar-border" />
          <nav className="space-y-1 px-3 py-3">
            {navItems.map((item) => (
              <button key={item.path} onClick={() => go(item.path)}
                className={cn("flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                  location.pathname === item.path ? "bg-sidebar-accent text-sidebar-primary border-l-2 border-l-sidebar-primary" : "text-sidebar-foreground/70 hover:bg-sidebar-accent"
                )}>
                <item.icon className="h-4 w-4" />{item.label}
              </button>
            ))}
            {isAdmin && (
              <>
                <Separator className="my-2 bg-sidebar-border" />
                <button onClick={() => go("/admin")}
                  className={cn("flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                    location.pathname === "/admin" ? "bg-sidebar-accent text-sidebar-primary border-l-2 border-l-sidebar-primary" : "text-sidebar-foreground/70 hover:bg-sidebar-accent"
                  )}>
                  <Shield className="h-4 w-4" />Admin Panel
                </button>
              </>
            )}
          </nav>
          <div className="mt-auto border-t border-sidebar-border px-3 py-3">
            <Button variant="ghost" size="sm" className="w-full justify-start text-sidebar-foreground/70" onClick={signOut}>
              <LogOut className="mr-2 h-4 w-4" />Sign Out
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </header>
  );
}
