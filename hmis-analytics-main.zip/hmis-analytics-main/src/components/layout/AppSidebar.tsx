import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import {
  LayoutDashboard, Upload, Target, CheckCircle, TrendingUp, FileText, Send, Shield, LogOut, Activity, MessageSquare,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";

const navItems = [
  { path: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { path: "/data-upload", label: "Data Upload", icon: Upload },
  { path: "/hospital-plans", label: "Hospital Plans", icon: Target },
  { path: "/data-quality", label: "Data Quality", icon: CheckCircle },
  { path: "/performance", label: "Performance", icon: TrendingUp },
  { path: "/reports", label: "Reports", icon: FileText },
  { path: "/feedback", label: "Feedback", icon: MessageSquare },
  { path: "/distribution", label: "Distribution", icon: Send },
];

const adminItems = [
  { path: "/admin", label: "Admin Panel", icon: Shield },
];

export default function AppSidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { profile, isAdmin, signOut } = useAuth();

  return (
    <aside className="hidden md:flex w-64 flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border">
      <div className="flex items-center gap-3 px-5 py-5">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-sidebar-primary animate-glow-pulse">
          <Activity className="h-5 w-5 text-sidebar-primary-foreground" />
        </div>
        <div>
          <h1 className="text-sm font-bold tracking-tight text-sidebar-foreground">HMIS Analytics</h1>
          <p className="text-xs text-sidebar-foreground/60">M&E Platform</p>
        </div>
      </div>

      <Separator className="bg-sidebar-border" />

      <ScrollArea className="flex-1 px-3 py-3">
        <nav className="space-y-1">
          {navItems.map((item) => (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={cn(
                "flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-all duration-200",
                location.pathname === item.path
                  ? "bg-sidebar-accent text-sidebar-primary border-l-2 border-l-sidebar-primary"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
              )}
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </button>
          ))}

          {isAdmin && (
            <>
              <Separator className="my-2 bg-sidebar-border" />
              {adminItems.map((item) => (
                <button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-all duration-200",
                    location.pathname === item.path
                      ? "bg-sidebar-accent text-sidebar-primary border-l-2 border-l-sidebar-primary"
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </button>
              ))}
            </>
          )}
        </nav>
      </ScrollArea>

      <div className="border-t border-sidebar-border px-3 py-3">
        <div className="mb-2 px-3">
          <p className="text-xs font-medium truncate">{profile?.full_name}</p>
          <p className="text-xs text-sidebar-foreground/50 truncate">{profile?.email}</p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="w-full justify-start text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent"
          onClick={signOut}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Sign Out
        </Button>
      </div>
    </aside>
  );
}
